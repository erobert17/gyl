/*
 Theme Name:   <?php echo $new_theme_title, "\n"; ?>
 Theme URI:    http://8theme.com/
 Description:  XStore Child Theme
 Author:       8theme
 Author URI:   http://8theme.com
 Template:     <?php echo $new_theme_template, "\n"; ?>
 Version:      1.0
 Text Domain:  xstore-child
*/